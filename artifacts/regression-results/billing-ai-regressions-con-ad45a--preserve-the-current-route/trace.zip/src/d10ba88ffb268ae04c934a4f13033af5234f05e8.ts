import { expect, test, type Route } from '@playwright/test';
import { getTrustedConnectionSources } from '../src/lib/cspSources';
import { shouldReloadForServiceWorkerControllerChange } from '../src/lib/serviceWorkerUpdate';
import { resolveSocketUrl, SOCKET_IO_PATH } from '../src/lib/socket';

const conversationId = 'regression-conversation-001';

const subscription = {
  status: 'active',
  plan: 'pro',
  planName: 'Pro',
  priceDisplay: '$29/month',
  hasActiveAccess: true,
  trialDaysRemaining: null,
  cancelAtPeriodEnd: false,
  entitlements: {
    crm: true,
    tasksProjects: true,
    teamChat: true,
    meetingsCalendar: true,
    fileStorage: true,
    aiAssistant: true,
    prioritySupport: true,
    advancedAnalytics: true,
  },
  limits: { members: 25, storage: 10_000_000_000, aiRequests: 500 },
  usage: {
    members: 1,
    pendingInvites: 0,
    memberSlotsUsed: 1,
    storageBytes: 0,
    aiRequests: 1,
    aiRequestsByUser: 1,
  },
};

const plans = ['free', 'starter', 'pro'].map((id, index) => ({
  id,
  name: id[0].toUpperCase() + id.slice(1),
  priceMonthly: index * 2900,
  priceDisplay: index ? `$${index * 29}/month` : 'Free',
  description: 'Regression test plan',
  highlighted: id === 'pro',
  entitlements: subscription.entitlements,
  limits: subscription.limits,
  features: [{ label: 'Workspace tools', included: true }],
}));

type AgentMessage = { role: 'user' | 'assistant'; content: string; createdAt: string };

async function setSessionAuth(page: import('@playwright/test').Page) {
  // Keep the app off the real Socket.IO server: its "Invalid token" reply to the
  // fixture token starts a session-recovery refresh that these tests count.
  await page.routeWebSocket('**/socket.io/**', (socket) => {
    socket.close({ code: 1000, reason: 'Socket.IO is not under test.' });
  });
  await page.addInitScript(() => {
    sessionStorage.setItem('workgrind_access_token', 'playwright-regression-access');
    sessionStorage.setItem('workgrind_refresh_token', 'playwright-regression-refresh');
  });
}

async function mockApi(
  route: Route,
  options: {
    messages: AgentMessage[];
    subscriptionRequests: number[];
    planRequests: number[];
    agentRequests: Array<{ conversationId?: string; history?: AgentMessage[]; message?: string }>;
    failFirstAgentRequest?: boolean;
    failSubscriptionRequestAt?: number;
    noSubscriptionRecord?: boolean;
    expireCurrentUserOnce?: { value: boolean };
    refreshStatus?: number;
    refreshDelayMs?: number;
    refreshRequests?: number[];
    currentUserTokens?: string[];
    unauthorizedPaths?: Map<string, number>;
  }
) {
  const request = route.request();
  const url = new URL(request.url());
  const pathname = url.pathname;
  const origin = request.headers().origin ?? 'http://127.0.0.1:3101';
  const headers = {
    'access-control-allow-origin': origin,
    'access-control-allow-credentials': 'true',
    'access-control-allow-methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
    'access-control-allow-headers': 'Authorization,Content-Type,Cache-Control',
  };

  if (request.method() === 'OPTIONS') {
    await route.fulfill({ status: 204, headers });
    return;
  }
  const unauthorizedPath = [...(options.unauthorizedPaths?.keys() ?? [])]
    .find((path) => pathname.endsWith(path));
  const remainingUnauthorizedResponses = unauthorizedPath
    ? options.unauthorizedPaths?.get(unauthorizedPath) ?? 0
    : 0;
  if (unauthorizedPath && remainingUnauthorizedResponses > 0) {
    options.unauthorizedPaths?.set(unauthorizedPath, remainingUnauthorizedResponses - 1);
    await route.fulfill({
      status: 401,
      headers,
      contentType: 'application/json',
      body: JSON.stringify({ success: false, message: 'Invalid or expired token' }),
    });
    return;
  }
  if (pathname.endsWith('/auth/me')) {
    options.currentUserTokens?.push(request.headers().authorization ?? '');
    if (options.expireCurrentUserOnce && !options.expireCurrentUserOnce.value) {
      options.expireCurrentUserOnce.value = true;
      await route.fulfill({
        status: 401,
        headers,
        contentType: 'application/json',
        body: JSON.stringify({ success: false, message: 'Invalid or expired token' }),
      });
      return;
    }
    await route.fulfill({
      status: 200,
      headers,
      contentType: 'application/json',
      body: JSON.stringify({
        success: true,
        user: {
          _id: 'playwright-user',
          fullName: 'Regression User',
          email: 'regression@example.invalid',
          role: 'owner',
          companyId: {
            _id: 'playwright-company',
            name: 'Regression Workspace',
            organizationType: 'business',
            accountType: 'company',
          },
          theme: 'light',
          preferredLanguage: 'en',
        },
      }),
    });
    return;
  }
  if (pathname.endsWith('/auth/refresh')) {
    options.refreshRequests?.push(Date.now());
    if (options.refreshDelayMs) {
      await new Promise((resolve) => setTimeout(resolve, options.refreshDelayMs));
    }
    await route.fulfill({
      status: options.refreshStatus ?? 200,
      headers,
      contentType: 'application/json',
      body: JSON.stringify(options.refreshStatus
        ? { success: false, message: 'Invalid or expired refresh token' }
        : { success: true, accessToken: 'playwright-refreshed-access' }),
    });
    return;
  }
  if (pathname.endsWith('/subscription/status')) {
    options.subscriptionRequests.push(Date.now());
    if (options.failSubscriptionRequestAt === options.subscriptionRequests.length) {
      await route.fulfill({
        status: 503,
        headers,
        contentType: 'application/json',
        body: JSON.stringify({ success: false, message: 'Subscription service is temporarily unavailable.' }),
      });
      return;
    }
    await route.fulfill({
      status: 200,
      headers,
      contentType: 'application/json',
      body: JSON.stringify({
        success: true,
        source: options.noSubscriptionRecord ? 'user_trial' : 'company',
        subscription: options.noSubscriptionRecord ? null : subscription,
      }),
    });
    return;
  }
  if (pathname.endsWith('/subscription/plans')) {
    options.planRequests.push(Date.now());
    await route.fulfill({
      status: 200,
      headers,
      contentType: 'application/json',
      body: JSON.stringify({ success: true, plans }),
    });
    return;
  }
  if (pathname.endsWith('/ai/agent/history')) {
    await route.fulfill({
      status: 200,
      headers,
      contentType: 'application/json',
      body: JSON.stringify({ success: true, conversations: [{ _id: conversationId, title: 'Regression chat' }] }),
    });
    return;
  }
  if (pathname.endsWith(`/ai/agent/conversations/${conversationId}`)) {
    await route.fulfill({
      status: 200,
      headers,
      contentType: 'application/json',
      body: JSON.stringify({
        success: true,
        conversation: { _id: conversationId, messages: options.messages },
      }),
    });
    return;
  }
  if (pathname.endsWith('/ai/agent') && request.method() === 'POST') {
    const body = request.postDataJSON() as {
      conversationId?: string;
      history?: AgentMessage[];
      message?: string;
    };
    options.agentRequests.push(body);
    if (options.failFirstAgentRequest && options.agentRequests.length === 1) {
      await route.fulfill({
        status: 503,
        headers,
        contentType: 'application/json',
        body: JSON.stringify({ success: false, message: 'Tavro AI is temporarily unavailable. Please retry.' }),
      });
      return;
    }
    const now = new Date().toISOString();
    options.messages.push(
      { role: 'user', content: body.message || '', createdAt: now },
      { role: 'assistant', content: 'OK response', createdAt: now }
    );
    const answer = 'OK response';
    const responseEvents = [
      `event: ready\ndata: ${JSON.stringify({ conversationId })}\n\n`,
      `event: delta\ndata: ${JSON.stringify({ text: answer })}\n\n`,
      `event: done\ndata: ${JSON.stringify({ conversationId, provider: 'gemini', toolSteps: [], tokensUsed: 1 })}\n\n`,
    ].join('');
    await route.fulfill({
      status: 200,
      headers,
      contentType: 'text/event-stream',
      body: responseEvents,
    });
    return;
  }

  await route.fulfill({
    status: 200,
    headers,
    contentType: 'application/json',
    body: JSON.stringify({ success: true, data: [], items: [], members: [], notifications: [] }),
  });
}

function makeApiState() {
  return {
    messages: [] as AgentMessage[],
    subscriptionRequests: [] as number[],
    planRequests: [] as number[],
    agentRequests: [] as Array<{ conversationId?: string; history?: AgentMessage[]; message?: string }>,
  };
}

test('Billing renders after its initial data fetch without repeatedly remounting or refetching', async ({ page }) => {
  const state = makeApiState();
  await setSessionAuth(page);
  await page.route('**/api/**', (route) => mockApi(route, {
    ...state,
    failSubscriptionRequestAt: undefined,
    failFirstAgentRequest: false,
  }));
  await page.goto('/billing');

  await expect(page.getByRole('heading', { name: 'Workspace Subscription', exact: true })).toBeVisible();
  await expect(page.getByText('Workspace Plan')).toBeVisible();
  await expect(page.getByText('Pro', { exact: true }).first()).toBeVisible();
  await page.waitForTimeout(1200);
  const settledSubscriptionRequests = state.subscriptionRequests.length;
  const settledPlanRequests = state.planRequests.length;
  await page.waitForTimeout(1500);

  expect(state.subscriptionRequests.length).toBe(settledSubscriptionRequests);
  expect(state.planRequests.length).toBe(settledPlanRequests);
  expect(settledSubscriptionRequests).toBeLessThanOrEqual(3);
  expect(settledPlanRequests).toBeLessThanOrEqual(2);
  await expect(page).toHaveURL(/\/billing$/);
});

test('Billing shows a retry state after a temporary subscription API failure', async ({ page }) => {
  const state = makeApiState();
  await setSessionAuth(page);
  await page.route('**/api/**', (route) => mockApi(route, {
    ...state,
    failSubscriptionRequestAt: 2,
    failFirstAgentRequest: false,
  }));
  await page.goto('/billing');

  await expect(page.locator('div[role="alert"].alert-danger')).toContainText(/Could not load|temporarily unavailable/i);
  await page.getByRole('button', { name: 'Retry loading billing data' }).click();
  await expect(page.getByRole('heading', { name: 'Workspace Subscription', exact: true })).toBeVisible();
  await expect(page.getByText('Workspace Plan')).toBeVisible();
});

test('Billing handles an account with no subscription record without fabricating a plan', async ({ page }) => {
  const state = makeApiState();
  await setSessionAuth(page);
  await page.route('**/api/**', (route) => mockApi(route, {
    ...state,
    failSubscriptionRequestAt: undefined,
    failFirstAgentRequest: false,
    noSubscriptionRecord: true,
  }));
  await page.goto('/billing');

  await expect(page.getByRole('heading', { name: 'Workspace Subscription', exact: true })).toBeVisible();
  await expect(page.getByRole('status')).toContainText('No subscription record is associated');
  await expect(page.getByText('No subscription', { exact: true })).toBeVisible();
  await expect(page.getByText('Available as a 7-day trial')).toBeVisible();
});

test('Tavro keeps the same conversation through the subscription refresh and restores it after reload', async ({ page }) => {
  const state = makeApiState();
  await setSessionAuth(page);
  await page.route('**/api/**', (route) => mockApi(route, {
    ...state,
    failSubscriptionRequestAt: undefined,
    failFirstAgentRequest: false,
  }));
  await page.goto('/ai');
  const composer = page.getByPlaceholder(/Ask me to find tasks/);
  await expect(composer).toBeVisible();
  await composer.fill('Reply with the word OK.');
  const navigationCount = { value: 0 };
  page.on('framenavigated', (frame) => {
    if (frame === page.mainFrame()) navigationCount.value += 1;
  });
  const mainFrameNavigations = navigationCount.value;
  await page.getByRole('button', { name: 'Send' }).click();
  await expect(page.getByText('OK response').first()).toBeVisible();
  await expect.poll(() => state.agentRequests.length).toBe(1);
  expect(state.agentRequests[0].conversationId).toBeUndefined();
  expect(navigationCount.value).toBe(mainFrameNavigations);
  await expect(page).toHaveURL(/\/ai$/);

  await page.reload();
  const restoredComposer = page.getByPlaceholder(/Ask me to find tasks/);
  await expect(restoredComposer).toBeVisible();
  await expect(page.getByText('Reply with the word OK.')).toBeVisible();
  await expect(page.getByText('OK response').first()).toBeVisible();

  await restoredComposer.fill('Continue in this same conversation.');
  await page.getByRole('button', { name: 'Send' }).click();
  await expect.poll(() => state.agentRequests.length).toBe(2);
  expect(state.agentRequests[1].conversationId).toBe(conversationId);
  await expect(page.getByText('Continue in this same conversation.')).toBeVisible();
  await expect(page.getByText('OK response').last()).toBeVisible();
  await expect(page).toHaveURL(/\/ai$/);
});

test('Tavro remains on the same route when /auth/me recovers through refresh', async ({ page }) => {
  const state = makeApiState();
  const currentUser401 = { value: false };
  const refreshRequests: number[] = [];
  const currentUserTokens: string[] = [];
  await setSessionAuth(page);
  await page.route('**/api/**', async (route) => {
    await mockApi(route, {
      ...state,
      failSubscriptionRequestAt: undefined,
      failFirstAgentRequest: false,
      expireCurrentUserOnce: currentUser401,
      currentUserTokens,
      refreshRequests,
    });
  });
  await page.goto('/ai');

  await expect(page.getByPlaceholder(/Ask me to find tasks/)).toBeVisible();
  await expect(page).toHaveURL(/\/ai$/);
  expect(refreshRequests).toHaveLength(1);
  expect(currentUser401.value).toBe(true);
  expect(currentUserTokens[0]).toBe('Bearer playwright-regression-access');
  expect(currentUserTokens).toHaveLength(2);
  expect(currentUserTokens.slice(1).every((token) => token === 'Bearer playwright-refreshed-access')).toBe(true);
});

test('repeatedly rejected refreshed sessions stop after one token-change retry', async ({ page }) => {
  const currentUserTokens: string[] = [];
  const refreshTokens: string[] = [];
  await setSessionAuth(page);
  await page.route('**/api/**', async (route) => {
    const request = route.request();
    const pathname = new URL(request.url()).pathname;
    if (pathname.endsWith('/auth/me')) {
      currentUserTokens.push(request.headers().authorization ?? '');
      await route.fulfill({
        status: 401,
        contentType: 'application/json',
        body: JSON.stringify({ success: false, message: 'Invalid or expired token' }),
      });
      return;
    }
    if (pathname.endsWith('/auth/refresh')) {
      const accessToken = `playwright-refreshed-access-${refreshTokens.length + 1}`;
      refreshTokens.push(accessToken);
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ success: true, accessToken }),
      });
      return;
    }
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ success: true }),
    });
  });

  await page.goto('/ai');
  await expect(page).toHaveURL(/\/login\?redirect=%2Fai$/);
  await expect.poll(() => currentUserTokens.length).toBe(4);
  expect(refreshTokens).toEqual([
    'playwright-refreshed-access-1',
    'playwright-refreshed-access-2',
  ]);
  await page.waitForTimeout(500);
  expect(currentUserTokens).toHaveLength(4);
  expect(refreshTokens).toHaveLength(2);
});

test('a protected request without an access token recovers through the refresh cookie', async ({ page }) => {
  const state = makeApiState();
  const refreshRequests: number[] = [];
  const missingTokenRequests: string[] = [];
  await setSessionAuth(page);
  await page.route('**/api/**', async (route) => {
    const request = route.request();
    const pathname = new URL(request.url()).pathname;
    if (pathname.endsWith('/subscription/status')) {
      const authorization = request.headers().authorization ?? '';
      if (!authorization) {
        missingTokenRequests.push(authorization);
        await route.fulfill({
          status: 401,
          contentType: 'application/json',
          body: JSON.stringify({ success: false, message: 'No token provided' }),
        });
        return;
      }
    }
    await mockApi(route, {
      ...state,
      failSubscriptionRequestAt: undefined,
      failFirstAgentRequest: false,
      refreshRequests,
    });
  });
  await page.goto('/billing');
  await expect(page.getByRole('heading', { name: 'Workspace Subscription', exact: true })).toBeVisible();
  await expect.poll(() => state.subscriptionRequests.length).toBeGreaterThan(0);
  await page.waitForTimeout(500);
  const initialSubscriptionRequests = state.subscriptionRequests.length;
  await page.evaluate(() => sessionStorage.removeItem('workgrind_access_token'));

  await page.getByRole('button', { name: 'Refresh' }).click();

  await expect.poll(() => state.subscriptionRequests.length).toBeGreaterThan(initialSubscriptionRequests);
  await expect.poll(() => refreshRequests.length).toBe(1);
  expect(missingTokenRequests).toEqual(['']);
  expect(refreshRequests).toHaveLength(1);
});

test('workspace creation waits for an authenticated session and redirects anonymous visitors', async ({ page }) => {
  let createCompanyRequests = 0;
  let refreshRequests = 0;
  const requestedUrls: string[] = [];
  page.on('request', (request) => requestedUrls.push(request.url()));
  await page.route('**/api/**', async (route) => {
    const pathname = new URL(route.request().url()).pathname;
    if (pathname.endsWith('/auth/refresh')) {
      refreshRequests += 1;
      await route.fulfill({
        status: 401,
        contentType: 'application/json',
        body: JSON.stringify({ success: false, message: 'Refresh token required' }),
      });
      return;
    }
    if (pathname.endsWith('/auth/create-company')) {
      createCompanyRequests += 1;
      await route.fulfill({
        status: 401,
        contentType: 'application/json',
        body: JSON.stringify({ success: false, message: 'No token provided' }),
      });
      return;
    }
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ success: true }),
    });
  });
  await page.goto('/create-company');

  await page.waitForTimeout(1000);
  expect(refreshRequests, requestedUrls.join('\n')).toBeGreaterThan(0);
  await expect(page).toHaveURL(/\/login\?redirect=%2Fcreate-company$/, {
    timeout: 15000,
  });
  expect(createCompanyRequests).toBe(0);
});

test('verified signup creates its workspace with the authenticated owner and stores the rotated access token', async ({ page }) => {
  let createCompanyAuthorization = '';
  let createCompanyBody: Record<string, unknown> | undefined;
  await setSessionAuth(page);
  await page.route('**/api/**', async (route) => {
    const request = route.request();
    const pathname = new URL(request.url()).pathname;
    if (pathname.endsWith('/auth/me')) {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          success: true,
          user: {
            _id: 'signup-owner',
            fullName: 'School Owner',
            email: 'school-owner@example.test',
            role: 'owner',
            accountType: 'company',
            signupOrganizationType: 'school',
            companyId: null,
          },
        }),
      });
      return;
    }
    if (pathname.endsWith('/subscription/status')) {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ success: true, subscription: { hasActiveAccess: false } }),
      });
      return;
    }
    if (pathname.endsWith('/auth/create-company')) {
      createCompanyAuthorization = request.headers().authorization ?? '';
      createCompanyBody = request.postDataJSON() as Record<string, unknown>;
      await route.fulfill({
        status: 201,
        contentType: 'application/json',
        body: JSON.stringify({
          success: true,
          accessToken: 'rotated-workspace-access',
          company: {
            _id: 'school-workspace',
            name: 'North School',
            ownerId: 'signup-owner',
            organizationType: 'school',
            accountType: 'company',
          },
          user: {
            _id: 'signup-owner',
            fullName: 'School Owner',
            email: 'school-owner@example.test',
            role: 'owner',
            accountType: 'company',
            companyId: 'school-workspace',
          },
        }),
      });
      return;
    }
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ success: true }),
    });
  });
  await page.goto('/create-company');
  await page.getByPlaceholder('Apex Technologies').fill('North School');
  await page.getByRole('button', { name: 'Launch Workspace' }).click();

  await expect.poll(() => createCompanyAuthorization).toBe('Bearer playwright-regression-access');
  expect(createCompanyAuthorization).toBe('Bearer playwright-regression-access');
  expect(createCompanyBody).toMatchObject({
    name: 'North School',
    accountType: 'company',
    organizationType: 'school',
  });
  await expect.poll(() => page.evaluate(() => sessionStorage.getItem('workgrind_access_token')))
    .toBe('rotated-workspace-access');
});

test('an expired or revoked refresh credential leaves a logged-out visitor on the public landing page', async ({ page }) => {
  const refreshRequests: number[] = [];
  const mainFrameNavigations: number[] = [];
  page.on('framenavigated', (frame) => {
    if (frame === page.mainFrame()) mainFrameNavigations.push(Date.now());
  });
  await page.route('**/api/**', (route) => mockApi(route, {
    ...makeApiState(),
    failSubscriptionRequestAt: undefined,
    failFirstAgentRequest: false,
    refreshStatus: 401,
    refreshRequests,
  }));

  await page.goto('/');
  await expect(page).toHaveURL(/\/$/);
  await expect(page.getByRole('link', { name: /sign in|log in/i }).first()).toBeVisible();
  await expect.poll(() => refreshRequests.length).toBe(1);
  const settledNavigations = mainFrameNavigations.length;
  await page.waitForTimeout(500);
  expect(mainFrameNavigations).toHaveLength(settledNavigations);
});

test('concurrent expired API requests share one refresh and preserve the current route', async ({ page }) => {
  test.setTimeout(120_000);
  const state = makeApiState();
  state.messages.push({
    role: 'assistant',
    content: 'Restored conversation',
    createdAt: new Date().toISOString(),
  });
  const refreshRequests: number[] = [];
  const unauthorizedPaths = new Map([
    ['/subscription/status', 1],
    [`/ai/agent/conversations/${conversationId}`, 1],
  ]);
  await page.addInitScript((id) => {
    sessionStorage.setItem('workgrind_access_token', 'playwright-expired-access');
    sessionStorage.setItem('workgrind:ai:active-conversation:playwright-user', id);
  }, conversationId);
  await page.routeWebSocket('**/socket.io/**', (socket) => {
    socket.close({ code: 1000, reason: 'Socket.IO is not under test.' });
  });
  await page.route('**/api/**', (route) => mockApi(route, {
    ...state,
    failSubscriptionRequestAt: undefined,
    failFirstAgentRequest: false,
    refreshDelayMs: 150,
    refreshRequests,
    unauthorizedPaths,
  }));
  await page.goto('/ai');

  await expect(page.getByPlaceholder(/Ask me to find tasks/)).toBeVisible();
  await expect(page.getByText('Restored conversation')).toBeVisible();
  expect(refreshRequests).toHaveLength(1);
  await expect(page).toHaveURL(/\/ai$/);
});

test('login 401 is not retried with a stale access token', async ({ page }) => {
  const refreshRequests: number[] = [];
  let loginRequests = 0;
  await page.route('**/api/**', async (route) => {
    const pathname = new URL(route.request().url()).pathname;
    if (pathname.endsWith('/auth/login')) {
      loginRequests += 1;
      await route.fulfill({
        status: 401,
        contentType: 'application/json',
        body: JSON.stringify({ success: false, message: 'Invalid credentials.' }),
      });
      return;
    }
    await mockApi(route, {
      ...makeApiState(),
      failSubscriptionRequestAt: undefined,
      failFirstAgentRequest: false,
      refreshStatus: 401,
      refreshRequests,
    });
  });
  await page.goto('/login');
  await page.getByLabel('Email address').fill('invalid@example.invalid');
  await expect.poll(() => refreshRequests.length).toBe(1);
  await page.evaluate(() => {
    sessionStorage.setItem('workgrind_access_token', 'playwright-stale-access');
  });
  await page.locator('#login-password').fill('not-a-real-secret');
  await page.getByRole('button', { name: /Sign in to WorkGrind/ }).click();

  await expect(page.locator('.auth-error[role="alert"]')).toContainText('Invalid credentials.');
  expect(loginRequests).toBe(1);
  expect(refreshRequests).toHaveLength(1);
  await expect(page).toHaveURL(/\/login$/);
});

test('logout does not refresh a session after its logout request is rejected', async ({ page }) => {
  await setSessionAuth(page);
  const refreshRequests: number[] = [];
  let logoutRequests = 0;
  await page.route('**/api/**', async (route) => {
    const pathname = new URL(route.request().url()).pathname;
    if (pathname.endsWith('/auth/logout')) {
      logoutRequests += 1;
      await route.fulfill({
        status: 401,
        contentType: 'application/json',
        body: JSON.stringify({ success: false, message: 'Session already expired.' }),
      });
      return;
    }
    await mockApi(route, {
      ...makeApiState(),
      failSubscriptionRequestAt: undefined,
      failFirstAgentRequest: false,
      refreshRequests,
    });
  });
  await page.goto('/ai');
  await expect(page.getByPlaceholder(/Ask me to find tasks/)).toBeVisible();
  await page.locator('aside button[aria-haspopup="menu"]').click();
  await page.getByRole('menuitem', { name: 'Sign out' }).click();

  await expect(page).toHaveURL(/\/login\?redirect=/);
  expect(logoutRequests).toBe(1);
  expect(refreshRequests).toHaveLength(0);
});

test('the initial service-worker takeover does not trigger a full-page reload', () => {
  expect(shouldReloadForServiceWorkerControllerChange(false, false)).toBe(false);
  expect(shouldReloadForServiceWorkerControllerChange(true, true)).toBe(false);
  expect(shouldReloadForServiceWorkerControllerChange(true, false)).toBe(true);
});

test('refresh requests from two tabs are serialized while refresh-token cookies rotate', async ({ browser }) => {
  const context = await browser.newContext();
  const firstPage = await context.newPage();
  const secondPage = await context.newPage();
  const activeRefreshRequests = { count: 0, maximum: 0 };
  const refreshCount = { count: 0 };
  const createPageHandler = (page401: { value: boolean }) => async (route: Route) => {
    const pathname = new URL(route.request().url()).pathname;
    if (pathname.endsWith('/auth/refresh')) {
      refreshCount.count += 1;
      activeRefreshRequests.count += 1;
      activeRefreshRequests.maximum = Math.max(activeRefreshRequests.maximum, activeRefreshRequests.count);
      await new Promise((resolve) => setTimeout(resolve, 100));
      const responseNumber = refreshCount.count;
      await route.fulfill({
        status: 200,
        headers: {
          'set-cookie': `wg_refresh=rotated-${responseNumber}; Path=/api/auth; HttpOnly; Secure; SameSite=Lax`,
        },
        contentType: 'application/json',
        body: JSON.stringify({ success: true, accessToken: `playwright-rotated-access-${responseNumber}` }),
      });
      activeRefreshRequests.count -= 1;
      return;
    }
    await mockApi(route, {
      ...makeApiState(),
      failSubscriptionRequestAt: undefined,
      failFirstAgentRequest: false,
      expireCurrentUserOnce: page401,
    });
  };

  await Promise.all([firstPage, secondPage].map((page) => page.addInitScript(() => {
    sessionStorage.setItem('workgrind_access_token', 'playwright-regression-access');
  })));
  await firstPage.route('**/api/**', createPageHandler({ value: false }));
  await secondPage.route('**/api/**', createPageHandler({ value: false }));
  await Promise.all([firstPage.goto('/ai'), secondPage.goto('/ai')]);
  await Promise.all([
    expect(firstPage.getByPlaceholder(/Ask me to find tasks/)).toBeVisible(),
    expect(secondPage.getByPlaceholder(/Ask me to find tasks/)).toBeVisible(),
  ]);

  expect(refreshCount.count).toBe(2);
  expect(activeRefreshRequests.maximum).toBe(1);
  await context.close();
});

test('production CSP connection sources include only the configured API and LiveKit origins plus ICE schemes', () => {
  expect(getTrustedConnectionSources(
    'https://backend-workgrind.vercel.app/api',
    'wss://work-grind-bjshvbs1.livekit.cloud',
  )).toEqual([
    'https://backend-workgrind.vercel.app',
    'wss://backend-workgrind.vercel.app',
    'wss://work-grind-bjshvbs1.livekit.cloud',
    'https://work-grind-bjshvbs1.livekit.cloud',
    'stun:',
    'turn:',
    'turns:',
  ]);
});

test('Socket.IO targets the configured backend and uses the Vercel function socket path', () => {
  expect(resolveSocketUrl(
    undefined,
    'https://backend-workgrind.vercel.app/api',
    'https://workgrind.vercel.app',
    false,
  )).toBe('https://backend-workgrind.vercel.app');
  expect(SOCKET_IO_PATH).toBe('/api/socket-io/socket.io');
});

test('Tavro shows retry controls when the agent API returns a server error', async ({ page }) => {
  const state = makeApiState();
  await setSessionAuth(page);
  await page.route('**/api/**', (route) => mockApi(route, {
    ...state,
    failSubscriptionRequestAt: undefined,
    failFirstAgentRequest: true,
  }));
  await page.goto('/ai');
  const composer = page.getByPlaceholder(/Ask me to find tasks/);
  await expect(composer).toBeVisible();
  await composer.fill('A harmless retry test.');
  await page.getByRole('button', { name: 'Send' }).click();
  await expect(page.locator('div[role="alert"].border-rose-300')).toContainText('Tavro AI is temporarily unavailable');
  await expect(page.getByRole('button', { name: 'Retry', exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'Retry', exact: true }).click();
  await expect(page.getByText('OK response')).toBeVisible();
  expect(state.agentRequests).toHaveLength(2);
});
